# Job Recruiter Dashboard UI

A Pen created on CodePen.io. Original URL: [https://codepen.io/aybukeceylan/pen/poEqdWZ](https://codepen.io/aybukeceylan/pen/poEqdWZ).

Design: https://dribbble.com/shots/11243208-Job-Recruiter-Dashboard-Dark-UI